DROP DATABASE IF EXISTS search_db;

DROP USER search_user;
