#! /bin/bash

java -jar search-html-to-json.jar config.properties
